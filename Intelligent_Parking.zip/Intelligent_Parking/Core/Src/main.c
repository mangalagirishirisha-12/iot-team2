
#include "main.h"
#include <stdio.h>
#include <string.h>

/* Peripheral handles */
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* Parking system variables */
volatile uint8_t button_pressed = 0;
uint8_t vehicle_detected = 0;
uint32_t echo_time = 0;
uint32_t distance = 0;

/* Function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
void Error_Handler(void);

uint32_t Ultrasonic_Read(void);
void Parking_Update(uint32_t distance_cm);
void UART_Status(uint32_t distance_cm);

/* USER CODE BEGIN 0 */

uint32_t Ultrasonic_Read(void)
{
    uint32_t start;
    uint32_t stop;
    uint32_t timeout;

    /* Send ultrasonic trigger pulse */
    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);
    __HAL_TIM_SET_COUNTER(&htim2, 0);

    while (__HAL_TIM_GET_COUNTER(&htim2) < 2U) {}

    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_SET);
    __HAL_TIM_SET_COUNTER(&htim2, 0);

    while (__HAL_TIM_GET_COUNTER(&htim2) < 10U) {}

    HAL_GPIO_WritePin(TRIG_GPIO_Port, TRIG_Pin, GPIO_PIN_RESET);

    /* Wait for ECHO to become HIGH */
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    timeout = 0;

    while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_RESET)
    {
        if (++timeout > 100000U)
            return 0;
    }

    start = __HAL_TIM_GET_COUNTER(&htim2);

    /* Wait for ECHO to become LOW */
    timeout = 0;

    while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET)
    {
        if (++timeout > 100000U)
            return 0;
    }

    stop = __HAL_TIM_GET_COUNTER(&htim2);

    if (stop >= start)
        echo_time = stop - start;
    else
        echo_time = (65536U - start) + stop;

    /* HC-SR04 distance calculation */
    distance = echo_time / 58U;

    return distance;
}

void Parking_Update(uint32_t distance_cm)
{
    if (distance_cm == 0U)
    {
        HAL_GPIO_WritePin(GPIOB,
            Red_LED_Pin | Yellow_LED_Pin | Green_LED_Pin,
            GPIO_PIN_RESET);
        return;
    }

    if (distance_cm < 10U)
    {
        /* Stop: object is very close */
        HAL_GPIO_WritePin(GPIOB, Red_LED_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, Yellow_LED_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, Green_LED_Pin, GPIO_PIN_RESET);
    }
    else if (distance_cm < 20U)
    {
        /* Caution */
        HAL_GPIO_WritePin(GPIOB, Red_LED_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, Yellow_LED_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, Green_LED_Pin, GPIO_PIN_RESET);
    }
    else
    {
        /* Safe */
        HAL_GPIO_WritePin(GPIOB, Red_LED_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, Yellow_LED_Pin, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, Green_LED_Pin, GPIO_PIN_SET);
    }
}

void UART_Status(uint32_t distance_cm)
{
    char msg[120];
    const char *status;

    if (distance_cm == 0U)
    {
        snprintf(msg, sizeof(msg),
                 "Distance: No echo - check sensor\r\n");
    }
    else
    {
        if (distance_cm < 10U)
            status = "STOP";
        else if (distance_cm < 20U)
            status = "CAUTION";
        else
            status = "SAFE";

        snprintf(msg, sizeof(msg),
                 "Distance: %lu cm | Status: %s | IR: %s\r\n",
                 (unsigned long)distance_cm,
                 status,
                 vehicle_detected ? "Detected" : "Not detected");
    }

    HAL_UART_Transmit(&huart2, (uint8_t *)msg,
                      (uint16_t)strlen(msg), 100);
}

/* USER CODE END 0 */

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_TIM2_Init();
    MX_TIM3_Init();
    MX_USART2_UART_Init();
    MX_USART3_UART_Init();

    /* Start timer for ultrasonic measurement */
    if (HAL_TIM_Base_Start(&htim2) != HAL_OK)
        Error_Handler();

    /*
     * Start PWM on TIM3 Channel 2 (PC7).
     * This is a 0% duty cycle initially because Pulse = 0.
     */
    if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2) != HAL_OK)
        Error_Handler();

    {
        char msg[] = "Intelligent Parking System Started\r\n";
        HAL_UART_Transmit(&huart2, (uint8_t *)msg,
                          sizeof(msg) - 1U, 100);
    }

    while (1)
    {
        /* Read IR sensor on PB0.
         * This assumes the sensor output is HIGH when a vehicle is detected.
         */
        vehicle_detected =
            (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == GPIO_PIN_SET);

        /* Measure distance */
        distance = Ultrasonic_Read();

        /* Control parking LEDs */
        Parking_Update(distance);

        /* Button toggles the relay/gate output */
        if (button_pressed)
        {
            button_pressed = 0;
            HAL_GPIO_TogglePin(GPIOB, Replay_Pin);
            HAL_Delay(200);
        }

        /* Send status to serial terminal */
        UART_Status(distance);

        HAL_Delay(100);
    }
}

/* Button interrupt callback */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == B1_Pin)
    {
        button_pressed = 1;
    }
}

/*
 * Keep your existing CubeMX-generated functions below:
 * SystemClock_Config()
 * MX_GPIO_Init()
 * MX_TIM2_Init()
 * MX_TIM3_Init()
 * MX_USART2_UART_Init()
 * MX_USART3_UART_Init()
 * Error_Handler()
 */
